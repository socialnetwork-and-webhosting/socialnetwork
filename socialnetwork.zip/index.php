<?php
  require_once 'header.php';
    $error = $user = $pass = "";
  if ($loggedin) {
    header('Location: home.php');
    die();
  }
?>
<hr>
<img src="background.jpg" style="width: 100%; border-radius: 30px;">
<hr>
<?php
  require_once 'banner.php';
?>
  </body>
</html>
