<?php
  require_once 'header.php';
  if (isset($_GET["limit"])) {
            $limit = $_GET["limit"];
        }
        else {
            $limit = 5;
        }
if (isset($_GET["offset"])) {
            $offset = $_GET["offset"];
        }
        else {
            $offset = 0;
        }
  if (!$loggedin) {
    header("Location: index.php");
    die();
  }

  echo "<hr>";
   showProfile($user);
?>
<div role="heading" class="ui-controlgroup-label"><legend>News Feed</legend></div><form method="get" action="home.php" target='_parent'>
<select data-role='button' data-inline='true' data-icon='arrow-u'
            data-transition="slide" name="offset">
  <option value="0">First (<?php echo $offset;?>)</option>
  <option value="10">10</option>
  <option value="20">20</option>
  <option value="50">50</option>
  <option value="100">100</option>
  <option value="200">200</option>
  <option value="500">500</option>
  <option value="1000">1000</option>
  <option value="2000">2000</option>
  <option value="5000">5000</option>
  <option value="10000">10000</option>
  <option value="20000">20000</option>
  <option value="50000">50000</option>
  <option value="100000">100000</option>
  <option value="200000">200000</option>
  <option value="500000">500000</option>
  <option value="1000000">1000000</option>
</select>
<select data-role='button' data-inline='true' data-icon='arrow-d'
            data-transition="slide" name="limit" onchange="this.form.submit()">
  <option value="0">Last (<?php echo $limit;?>)</option>
  <option value="10">10</option>
  <option value="20">20</option>
  <option value="50">50</option>
  <option value="100">100</option>
  <option value="200">200</option>
  <option value="500">500</option>
  <option value="1000">1000</option>
  <option value="2000">2000</option>
  <option value="5000">5000</option>
  <option value="10000">10000</option>
  <option value="20000">20000</option>
  <option value="50000">50000</option>
  <option value="100000">100000</option>
  <option value="200000">200000</option>
  <option value="500000">500000</option>
  <option value="1000000">1000000</option>
</select>
</form><br>
<?php
  if (isset($_POST['erase']))
  {
    $erase = sanitizeString($_POST['erase']);
    $r2 = queryMysql("DELETE FROM messages WHERE id=$erase AND recip='$user'");
    if($r2)
      echo "";
    else
      echo "";
  }
  
  $result = queryMysql("SELECT messages.* FROM messages INNER JOIN friends ON messages.recip=friends.user WHERE friends.friend='$user' AND messages.pm=0 ORDER BY messages.id desc LIMIT $limit OFFSET $offset");
  $result2 = queryMysql("SELECT messages.* FROM messages WHERE messages.pm=0 and (messages.recip='$user' OR messages.auth='$user') ORDER BY messages.id desc LIMIT $limit OFFSET $offset");
  $num    = $result->num_rows;
  $rows = array();
  for ($j = 0 ; $j < $num ; ++$j)
  {
    $rows[] = $result->fetch_array(MYSQLI_ASSOC);
  }
  $result = $rows;
  $num    = $result2->num_rows;
  $rows2 = array();
    for ($j = 0 ; $j < $num ; ++$j)
    {
      $rows2[] = $result2->fetch_array(MYSQLI_ASSOC);
    }
    $result2 = $rows2;
  $results = array_merge($result,$result2);

  function cmp($a,$b){

    if ($a['id']>$b['id'])
      return 0;
    else
      return 1;
  }

  usort($results, "cmp");

  $results = array_map("unserialize", array_unique(array_map("serialize", $results)));
  
  foreach ($results as $row)
  {

    echo date('d-m-Y H:i:s', $row['time']);
    echo " <a href='members.php?view=" . $row['auth'] . "'>" . $row['auth']. "</a>: ";

    echo " <a href='members.php?view=" . $row['recip'] . "'>" . $row['recip']. "</a>. ";

$bbtext = $row['message'];
$row['message'] = showBBcodes($bbtext);
    echo "<fieldset data-role='controlgroup' data-type='horizontal'><legend><label for='public'>Public</label></legend> " . $row['message'] . " </fieldset> ";
    if ($row['recip'] == $user){
      $id = $row["id"];
      echo "<button data-role='button' data-inline='true' data-icon='delete'
            data-transition='slide' class='deleteMessage' data='$id'>Delete</button>";
      echo "<form id='message$id' method='post' action='home.php' target='_parent'>
      <input type='hidden' name='erase' value='{$id}'>
      </form>";

    }
    echo "<hr>";
  }
    echo "<br>";

?>
  </div>
  <script type="text/javascript">
    $('.deleteMessage').click(function  () {
      $('#message'+$(this).attr('data')).submit();
    })
  </script>
  <a data-role='button'
        href='home.php' target='_parent'>Refresh Page</a><br>
  </body>
</html>
