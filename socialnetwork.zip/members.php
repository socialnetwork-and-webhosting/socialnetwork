<?php
  require_once 'header.php';

if (isset($_GET['lists']))
  {
    $lists = sanitizeString($_GET['lists']);
setcookie ("limit",$_GET["limit"],strtotime( '+360 days' ) );
setcookie ("offset",$_GET["offset"],strtotime( '+360 days' ) );
  }
if (isset($_GET["limit"])) {
            $limit = $_GET["limit"];
        }
        else {
            $limit = 0;
        }
if (isset($_GET["offset"])) {
            $offset = $_GET["offset"];
        }
        else {
            $offset = 0;
        }
  if (!$loggedin) die("</div></body></html>");

  if (isset($_GET['view']))
  {
    $view = sanitizeString($_GET['view']);
    
    if ($view == $user) $name = "Your";
    else                $name = "$view's";
    
    echo "<h3>$name Profile";
    

  if (isset($_GET['add']))
  {
    $add = sanitizeString($_GET['add']);

    $result = queryMysql("SELECT * FROM friends WHERE user='$add' AND friend='$user'");
    if (!$result->num_rows)
      queryMysql("INSERT INTO friends VALUES ('$add', '$user')");
  }
  elseif (isset($_GET['remove']))
  {
    $remove = sanitizeString($_GET['remove']);
    queryMysql("DELETE FROM friends WHERE user='$remove' AND friend='$user'");
  }
{
    
    $follow = "Add as Friend";

    $result1 = queryMysql("SELECT * FROM friends WHERE
      user='$view' AND friend='$user'");
    $t1      = $result1->num_rows;
    $result1 = queryMysql("SELECT * FROM friends WHERE
      user='$user' AND friend='$view'");
    $t2      = $result1->num_rows;

    if (($t1 + $t2) > 1) echo " &harr; is a mutual friend";
    elseif ($t1)         echo " &larr; you are following";
    elseif ($t2)       { echo " &rarr; is following you";
                         $follow = "Confirm"; }
    
    if (!$t1) echo " <a data-role='button' data-inline='true' data-icon='plus'
            data-transition='slide' href='members.php?add=$view&view=$view'>$follow</a></h3>";
    else      echo " <a data-role='button' data-inline='true' data-icon='delete'
            data-transition='slide' href='members.php?remove=$view&view=$view'>Remove</a></h3>";
}
    
    showProfile($view);
    echo "<a data-role='button' data-transition='slide'
          href='messages.php?view=$view' target='_parent'>View $name messages</a>";
    die("</div></body></html>");
 } 

  if (isset($_GET['add']))
  {
    $add = sanitizeString($_GET['add']);

    $result = queryMysql("SELECT * FROM friends WHERE user='$add' AND friend='$user'");
    if (!$result->num_rows)
      queryMysql("INSERT INTO friends VALUES ('$add', '$user')");
  }
  elseif (isset($_GET['remove']))
  {
    $remove = sanitizeString($_GET['remove']);
    queryMysql("DELETE FROM friends WHERE user='$remove' AND friend='$user'");
  }

  $result = queryMysql("SELECT user FROM members ORDER BY user LIMIT $limit OFFSET $offset");
  $num    = $result->num_rows;

  echo "<h3>Find Members</h3><form method='get' action='members.php?lists'>
        <div data-role='fieldcontain'>
          <label>First</label><input type='number' value='".$_COOKIE["offset"]."' name='offset' placeholder='0' required='required'>
      </div>        
        <div data-role='fieldcontain'>
          <label>Last</label><input type='number' value='".$_COOKIE["limit"]."' name='limit' placeholder='100' required='required'>
          </div>
<div data-role='fieldcontain'>
          <label></label><input  data-transition='slide' type='submit' value='Find' /></div>
</form><br>";
if (isset($_GET['lists']))
  {
echo "<span class='subhead'>List of Members</span><ul>";
  }
  for ($j = 0 ; $j < $num ; ++$j)
  {
    $row = $result->fetch_array(MYSQLI_ASSOC);
    if ($row['user'] == $user) continue;
 
    echo "<li><a data-transition='slide' href='members.php?view=" .
      $row['user'] . "'>" . $row['user'] . "</a>";
    $follow = "Add as Friend";

    $result1 = queryMysql("SELECT * FROM friends WHERE
      user='" . $row['user'] . "' AND friend='$user'");
    $t1      = $result1->num_rows;
    $result1 = queryMysql("SELECT * FROM friends WHERE
      user='$user' AND friend='" . $row['user'] . "'");
    $t2      = $result1->num_rows;

    if (($t1 + $t2) > 1) echo " &harr; is a mutual friend";
    elseif ($t1)         echo " &larr; you are following";
    elseif ($t2)       { echo " &rarr; is following you";
                         $follow = "Confirm"; }
    
    if (!$t1) echo " <a data-role='button' data-inline='true' data-icon='plus'
            data-transition='slide' href='members.php?add=" . $row['user'] . "'>$follow</a>";
    else      echo " <a data-role='button' data-inline='true' data-icon='delete'
            data-transition='slide' href='members.php?remove=" . $row['user'] . "'>Remove</a>";
  }
?>
    </ul></div>
  </body>
</html>
