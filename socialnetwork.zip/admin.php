<?
  require_once 'header.php';
if (isset($_GET['clear']))
  {
    $delete = sanitizeString($_GET['clear']);
queryMysql("DELETE FROM messages WHERE id");
  }
if (isset($_GET['delete']))
  {
    $delete = sanitizeString($_GET['delete']);
$username = $_GET['username'];
queryMysql("DELETE FROM members WHERE user='$username'");
queryMysql("DELETE FROM friends WHERE user='$username'");
queryMysql("DELETE FROM friends WHERE friend='$username'");
queryMysql("DELETE FROM profiles WHERE user='$username'");
queryMysql("DELETE FROM messages WHERE auth='$username'");
queryMysql("DELETE FROM messages WHERE recip='$username'");
  }


if($user == "admin")
{
print "<br><form method='GET' action='admin.php?delete'>
<h3>Delete Members</h3>
      <div data-role='fieldcontain'>
        <label>Username</label>
        <input type='text' maxlength='16' name='username' value=''>
      </div>
      <div data-role='fieldcontain'>
        <label></label>
        <input data-transition='slide' type='submit' value='Delete'><hr>
      </div>
      </form></div><br><a data-role='button'
        href='admin.php?clear' target='_parent'>Clear Messages</a>";
}
else
{
echo "<br><h3>You are not logged in as an administrator.</h3>";
}

?>
</body>
</html>
