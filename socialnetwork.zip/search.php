  <?php
  require_once 'header.php';

  if (!$loggedin) {
    header("Location: index.php");
    die();
  }
  echo "<h3>Search Members</h3><form action='search.php' method='post' name='search' id='search'>
          
        <div data-role='fieldcontain'>
          <label>Username</label>
  <input type='text' name='search' placeholder='' required='required'>
  </div><div data-role='fieldcontain'>
          <label></label><input  data-transition='slide' type='submit' value='Search' /></div>
  </form>";

    echo "<br>";

  if (isset($_POST['search'])) {
    if (strpos($_POST['search'],'@') !== false) {
      $query = sanitizeString($_POST['search']);
      $result= queryMysql("SELECT * FROM members WHERE user LIKE '$query'");
      $num   = $result->num_rows;
      for ($j = 0 ; $j < $num ; ++$j){ 
        $row = $result->fetch_array(MYSQLI_ASSOC);
        if ($row['user'] == $user) continue;
        $u = $row['user'];
        echo "<br>";
        }
      } else {
        $query = sanitizeString($_POST['search']);
        $result= queryMysql("SELECT * FROM members WHERE user LIKE '%$query%'");

        $num   = $result->num_rows;
        echo "<span class='subhead'>Results</span><ul>";
        for ($j = 0 ; $j < $num ; ++$j){ 
          $row = $result->fetch_array(MYSQLI_ASSOC);
          if ($row['user'] == $user) continue;
          /**/
          $u = $row['user'];
          if (file_exists)
   
    echo "<li><a data-transition='slide' href='members.php?view=".$u."'>".$u."</a></li>";
    
	else
		echo "<br>";
        }

      }

    } 
    echo "</ul>";
    ?>
 </div>
  </body>
  </html>
